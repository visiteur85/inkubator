import React from 'react';

export const CountResult = () => {
    return (
        <div>
            
            </div>
    );
};

export default CountResult;
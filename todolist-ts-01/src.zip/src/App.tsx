import React from 'react';
import './App.css';
import {Todolist} from "./Todolist";


function App() {

    const task1 = [
        {id: 1, title: "Hello word11111", isDone: true},
        {id: 2, title: "I am happy11111", isDone: false},
        {id: 3, title: "Yo11111", isDone: false},

    ]

    const task2 = [
        {id: 1, title: "Hello word22222", isDone: true},
        {id: 2, title: "I am happy22222", isDone: false},
        {id: 3, title: "Yo22222", isDone: false},

    ]


    return (
        <div className="App">
            <Todolist title={"What is learn11111"} tasks={task1} />
            <Todolist title={"What is learn22222"} tasks={task2}/>
            <Todolist title={"What is learn33333"} tasks={task2}/>
        </div>
    );
}

export default App; 

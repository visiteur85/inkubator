import React from 'react';

import {LinearProgress} from "@mui/material";


export const Preloader = () => {
    return (
        <LinearProgress color="secondary"/>
    );
};

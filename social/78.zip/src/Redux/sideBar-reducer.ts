import React from 'react';


export type SidebarType = {};
let initialState: SidebarType = {}

export const sideBarReducer = (state = initialState, action:any)=> {
    return state
}
import React from 'react';

export const Login = () => {
    return (
       <h1>LOGIN</h1>


    );
};


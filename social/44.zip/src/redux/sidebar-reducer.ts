export const sidebarReducer = (state:any, action: any)=>{

    return state
}
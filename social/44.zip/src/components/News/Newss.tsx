import React from 'react';

export const Newss = () => {
    return (
        <div>
            sadfasdfasdkfja;dkjfsa;kdjfs
        </div>
    );
};
